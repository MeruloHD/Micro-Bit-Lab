#include "gpio.h"
#include "uart.h"

int lights_on= 0;

void revert_lights(){
    if(lights_on){
        gpio_lights_off();
        lights_on = 0;
    }
    else{
        gpio_lights_on();
        lights_on = 1;
    }

}

int main(){

    gpio_init();
    uart_init();

    while (1){
        if(button_A_pressed()){
            uart_send('A');
            revert_lights();
            while (button_A_pressed());
            
        }
        else if(button_B_pressed()){
            uart_send('B');
            revert_lights();
            while (button_B_pressed());
        }
    }
    
    return 0;
}