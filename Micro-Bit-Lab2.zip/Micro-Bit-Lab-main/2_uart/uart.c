#include "uart.h"

void uart_init(){

    UART_MODULE->PSEL_RXD = 8 | (1<<5);
    UART_MODULE->PSEL_TXD = 6;


    UART_MODULE->PSEL_RTS = 0xFFFFFFFF;     //DISABLE
    UART_MODULE->PSEL_CTS = 0xFFFFFFFF;     //DISABLE


    UART_MODULE->ENABLE =4;

    UART_MODULE->BAUDRATE = 0x00275000;

    UART_MODULE->TASKS_STARTTX =1;

    // GPIO1->PIN_CNF[8] = 1;  //TX OUTPUT

    // GPIO0->PIN_CNF[6] = 0;  //RX  INPUT

    //UART_MODULE->PSEL_TXD = 4;
};


void uart_send(char letter){
    UART_MODULE->TASKS_STARTTX =1;

    UART_MODULE->TXD = letter;

    while(UART_MODULE->EVENTS_TXDRDY == 0){
        continue;
    }

    UART_MODULE->EVENTS_TXDRDY = 0;     //Sette heller startTX til 0?

    UART_MODULE->TASKS_STOPTX = 1;
}

char uart_read(){
    if(UART_MODULE->EVENTS_RXDRDY == 1){
        return '\0';
    }

    UART_MODULE->EVENTS_RXDRDY = 0;

    char answer = UART_MODULE->RXD;

    return answer;

};


int button_A_pressed(){
   return (GPIO0->IN & (1 << 14));      //INVERS?

};

int button_B_pressed(){
    return (GPIO0->IN & (1 << 23));
}


